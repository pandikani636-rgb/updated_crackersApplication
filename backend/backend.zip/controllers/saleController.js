const Sale = require('../models/Sale');

// Helper to generate invoice number
const generateInvoiceNumber = async () => {
  const count = await Sale.countDocuments();
  const dateStr = new Date().toISOString().slice(0, 7).replace('-', '');
  const seq = String(count + 1).padStart(4, '0');
  return `INV-${dateStr}-${seq}`;
};

// @desc    Get all sales
// @route   GET /api/sales
const getSales = async (req, res) => {
  try {
    const sales = await Sale.find({}).sort({ createdAt: -1 });
    res.json(sales);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Create a new sale
// @route   POST /api/sales
const createSale = async (req, res) => {
  try {
    const {
      invoiceNumber,
      customerName,
      date,
      items,
      subtotal,
      hasGst,
      gstPercentage,
      gstAmount,
      grandTotal,
      notes
    } = req.body;

    const invNum = invoiceNumber || (await generateInvoiceNumber());
    
    // Process items ensuring line totals are calculated
    const processedItems = (items || []).map(i => ({
      quantity: Number(i.quantity) || 1,
      item: i.item || '',
      amountPerItem: Number(i.amountPerItem) || 0,
      totalAmount: (Number(i.quantity) || 1) * (Number(i.amountPerItem) || 0)
    }));

    const computedSubtotal = subtotal !== undefined 
      ? Number(subtotal) 
      : processedItems.reduce((acc, curr) => acc + curr.totalAmount, 0);
      
    const isGst = Boolean(hasGst);
    const gstPct = isGst ? (Number(gstPercentage) || 0) : 0;
    const computedGstAmt = isGst 
      ? (gstAmount !== undefined ? Number(gstAmount) : computedSubtotal * (gstPct / 100))
      : 0;
    const computedGrandTotal = grandTotal !== undefined 
      ? Number(grandTotal) 
      : (computedSubtotal + computedGstAmt);

    const sale = new Sale({
      invoiceNumber: invNum,
      customerName: customerName || 'Walk-in Customer',
      date: date || new Date().toISOString().split('T')[0],
      items: processedItems,
      subtotal: computedSubtotal,
      hasGst: isGst,
      gstPercentage: gstPct,
      gstAmount: computedGstAmt,
      grandTotal: computedGrandTotal,
      notes: notes || ''
    });

    const createdSale = await sale.save();
    res.status(201).json(createdSale);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Update a sale
// @route   PUT /api/sales/:id
const updateSale = async (req, res) => {
  try {
    const sale = await Sale.findById(req.params.id);
    if (sale) {
      Object.assign(sale, req.body);
      const updatedSale = await sale.save();
      res.json(updatedSale);
    } else {
      res.status(404).json({ message: 'Sale record not found' });
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Delete a sale
// @route   DELETE /api/sales/:id
const deleteSale = async (req, res) => {
  try {
    const sale = await Sale.findById(req.params.id);
    if (sale) {
      await Sale.deleteOne({ _id: req.params.id });
      res.json({ message: 'Sale record removed' });
    } else {
      res.status(404).json({ message: 'Sale record not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getSales,
  createSale,
  updateSale,
  deleteSale
};
