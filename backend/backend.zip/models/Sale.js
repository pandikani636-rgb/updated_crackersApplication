const mongoose = require('mongoose');

const SaleItemSchema = new mongoose.Schema({
  quantity: { type: Number, required: true, default: 1 },
  item: { type: String, required: true },
  amountPerItem: { type: Number, required: true, default: 0 },
  totalAmount: { type: Number, required: true, default: 0 }
});

const SaleSchema = new mongoose.Schema({
  invoiceNumber: { type: String, required: true },
  customerName: { type: String, required: true },
  date: { type: String, required: true },
  items: [SaleItemSchema],
  subtotal: { type: Number, required: true, default: 0 },
  hasGst: { type: Boolean, default: false },
  gstPercentage: { type: Number, default: 0 },
  gstAmount: { type: Number, default: 0 },
  grandTotal: { type: Number, required: true, default: 0 },
  notes: { type: String, default: '' }
}, { strict: false, timestamps: true });

const Sale = mongoose.model('Sale', SaleSchema);

module.exports = Sale;
